package principal;
//Guilherme dos Santos,Isabella Dichirico,
import dados.UsuarioDados;
import model.bean.Usuario;

public class Principal {
    public static void main(String[] args) {

        Usuario u = new Usuario();
        u.setNome("Guilherme");
        u.setSobrenome("Medeiros");
        u.setEmail("gui3191@gmail.com");
        u.setCPF("12345678910");
        u.setSenha("Abubable");

        new UsuarioDados().cadastrarU(u);
    }
}
