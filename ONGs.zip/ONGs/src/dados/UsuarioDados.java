package dados;

import conexao.Conexao;
import model.bean.Usuario;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UsuarioDados {

    public void cadastrarU (Usuario usuario){
        String sql = "INSERT INTO USUARIO (NOME, SOBRENOME,EMAIL, CPF, SENHA) VALUES(?,?,?,?,?)";

        PreparedStatement ps = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setString(1,usuario.getNome());
            ps.setString(2,usuario.getSobrenome());
            ps.setString(3,usuario.getEmail());
            ps.setString(4,usuario.getCPF());
            ps.setString(5,usuario.getSenha());

            ps.execute();
            ps.close();


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
